#!/usr/bin/env python3

import numpy as np
import casadi as ca
import rospy
from qcar_control.msg import TrajectoryMessage
from std_msgs.msg import Float32
from geometry_msgs.msg import Vector3Stamped, TransformStamped

import pandas as pd
from shapely.geometry import Polygon, Point

# Set matplotlib backend to 'Agg' before importing pyplot
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import cv2  # Import OpenCV for video writing
import io
from PIL import Image

class MPCControllerSimulation:
    def __init__(self):
        rospy.init_node('mpc_controller_simulation')

        # Vehicle and Motor Parameters
        self.a = 0.12960  # Distance to front axle from center (m)
        self.b = 0.12960  # Distance to rear axle from center (m)
        self.L = self.a + self.b  # Wheelbase length (m)
        self.r_wheel = 0.033  # Wheel radius (m)
        self.mass = 3.0  # Vehicle mass (kg)
        self.J = 0.1  # Wheel moment of inertia (kg·m²)
        self.c_d = 0.1  # Damping coefficient (adjust as needed)

        # Qcar constraints
        self.gear_ratio = 4.0 #2.7    # 4:1 gear ratio

        # Motor constants
        self.R_a = 0.47  # Armature resistance (Ohm)
        self.L_a = 0.5  # Armature inductance (H)
        self.K_t = 0.0027  # Torque constant (N·m/A)
        self.K_b = 0.0027  # Back-EMF constant (V·s/rad)
        self.V_max = 12.0  # Maximum voltage (V)

        # Maximum torque calculation
        self.I_max = self.V_max / self.R_a  # Max current (A)
        self.tau_max_motor = self.K_t * self.I_max  # Max motor torque (N·m)
        self.tau_max = self.tau_max_motor * self.gear_ratio  # Max wheel torque (N·m)
        self.tau_min = -self.tau_max  # Min wheel torque (N·m) (allowing for braking)

        # Steering constraints
        self.delta_max = np.radians(30)  # Maximum steering angle (rad)
        self.delta_min = -self.delta_max

        # Time step and horizon
        self.dt = 0.0333  # Time step (s)
        self.N = int(1.0/self.dt) # Prediction horizon

        # Weights for the cost function
        self.w_pos = 100.0   # Position tracking weight
        self.w_psi = 00.001   # Heading tracking weight
        self.w_v = 10.0     # Velocity tracking weight
        self.w_u_p =100.0   # Torque control input weight
        self.w_u_d = 100.0   # Steering control input weight
        self.w_tau_current = 0.001  # Weight for torque-current alignment

        # Define maximum and minimum acceleration (m/s²)
        self.a_max = 1.2  # Maximum acceleration
        self.a_min = -0.5  # Maximum deceleration

        # Calculate maximum and minimum change in velocity per time step
        self.delta_v_max = self.a_max * self.dt  # e.g., 1.2 * 0.05 = 0.06 m/s
        self.delta_v_min = self.a_min * self.dt  # e.g., -0.5 * 0.05 = -0.025 m/s

        # Slew rate limits for steering
        self.delta_rate_limit = (2 * self.delta_max) / 0.05  # rad/s
        self.delta_delta_max = self.delta_rate_limit * self.dt  # rad per time step

        self.steering_cmd_prev = 0.0  # Initialize previous steering command
        self.PWM_cmd_prev = 0.0  # Initialize previous PWM command

        # Define maximum change in PWM per time step
        self.delta_PWM_max_up = 0.40     # Maximum increase in PWM per time step
        self.delta_PWM_max_down = -0.05  # Maximum decrease in PWM per time step

        # Initialize state and waypoints
        self.current_state = np.zeros(4)  # [x, y, psi, v]
        # Initial position will be updated when first Vicon data is received

        self.waypoint_times = []
        self.waypoint_x = []
        self.waypoint_y = []
        self.waypoint_velocity = []
        self.initial_waypoints_received_time = None
        self.waypoints_received = False

        # Initialize motor current
        self.motor_current = 0.0  # Initialize motor current

        # Read and process the track boundaries
        self.read_and_process_track_boundaries()

        # Setup ROS subscribers and publishers
        self.init_subscribers()
        self.init_publishers()

        # Setup MPC problem
        self.setup_mpc()

        # Flags for plotting
        self.initial_position_plotted = False
        # Removed self.trajectory_plotted to allow continuous plotting
        self.pause = False

        # Initialize video writer
        self.init_video_writer()

        # List to store vehicle positions for plotting (optional)
        self.trajectory_history = []

        # Current Waypoint (to be highlighted)
        self.current_waypoint = None

    def init_video_writer(self):
        """
        Initialize the video writer using OpenCV.
        """
        # Define the codec and create VideoWriter object
        # 'mp4v' is a commonly supported codec for MP4
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        self.video_filename = './src/qcar_control/trajectory_video.mp4'
        self.fps = 10  # Frames per second

        # Define figure size in inches and DPI to calculate pixel dimensions
        self.fig_width = 10
        self.fig_height = 8
        self.dpi = 100  # Dots per inch

        # Calculate pixel dimensions
        self.frame_width = int(self.fig_width * self.dpi)
        self.frame_height = int(self.fig_height * self.dpi)

        # Initialize VideoWriter
        self.video_writer = cv2.VideoWriter(
            self.video_filename,
            fourcc,
            self.fps,
            (self.frame_width, self.frame_height)
        )

        if not self.video_writer.isOpened():
            rospy.logerr(f"Failed to open video writer with filename {self.video_filename}")
            rospy.signal_shutdown("VideoWriter initialization failed.")

        rospy.loginfo(f"Video writer initialized. Saving video to {self.video_filename}")

    def init_subscribers(self):
        rospy.Subscriber("/qcar/trajectory_topic", TrajectoryMessage, self.guid_callback)
        rospy.Subscriber('/qcar/velocity', Vector3Stamped, self.velocity_callback)
        rospy.Subscriber("/vicon/qcar/qcar", TransformStamped, self.vicon_callback)
        rospy.Subscriber('/qcar/motorcurrent', Float32, self.motor_current_callback)  # Added subscriber

    def init_publishers(self):
        self.cmd_pub = rospy.Publisher('qcar/user_command', Vector3Stamped, queue_size=1)

    def motor_current_callback(self, msg):
        """
        Callback function to handle incoming motor current data.
        """
        self.motor_current = msg.data
        rospy.logdebug(f"Received motor current: {self.motor_current:.4f} A")

    def read_and_process_track_boundaries(self):
        # Read the cones.csv file
        try:
            cones_df = pd.read_csv('./src/qcar_guidance/vicon_data.csv')
        except FileNotFoundError:
            rospy.logerr("vicon_data.csv file not found in './src/qcar_guidance/'. Please check the file path.")
            rospy.signal_shutdown("Missing vicon_data.csv file.")
            return

        # Separate inner (yellow) and outer (blue) cones
        inner_cones = cones_df[cones_df['tag'] == 'yellow']
        outer_cones = cones_df[cones_df['tag'] == 'blue']

        # Get the x and y coordinates
        inner_coords = list(zip(inner_cones['x'], inner_cones['y']))
        outer_coords = list(zip(outer_cones['x'], outer_cones['y']))

        # Ensure the polygons are properly closed
        if inner_coords and inner_coords[0] != inner_coords[-1]:
            inner_coords.append(inner_coords[0])
        if outer_coords and outer_coords[0] != outer_coords[-1]:
            outer_coords.append(outer_coords[0])

        # Create polygons for the inner and outer boundaries
        self.inner_boundary_polygon = Polygon(inner_coords)
        self.outer_boundary_polygon = Polygon(outer_coords)

        # Check if polygons are valid
        if not self.inner_boundary_polygon.is_valid:
            self.inner_boundary_polygon = self.inner_boundary_polygon.buffer(0)
            rospy.logwarn("Fixed invalid inner boundary polygon using buffer.")
        if not self.outer_boundary_polygon.is_valid:
            self.outer_boundary_polygon = self.outer_boundary_polygon.buffer(0)
            rospy.logwarn("Fixed invalid outer boundary polygon using buffer.")

        # Shrink the track boundaries by 0.05 meters
        shrink_distance = -0.05  # Negative value to shrink
        self.shrunken_outer_boundary = self.outer_boundary_polygon.buffer(shrink_distance)
        self.shrunken_inner_boundary = self.inner_boundary_polygon.buffer(-shrink_distance)

        # Compute the track area after shrinking
        self.track_polygon = self.shrunken_outer_boundary.difference(self.shrunken_inner_boundary)

        # Extract boundary constraints
        self.outer_boundary_constraints = self.compute_boundary_constraints(self.shrunken_outer_boundary)
        self.inner_boundary_constraints = self.compute_boundary_constraints(self.shrunken_inner_boundary)

        rospy.loginfo("Track boundaries processed and constraints computed.")

    def compute_boundary_constraints(self, boundary_polygon):
        # Extract the exterior coordinates of the polygon
        coords = list(boundary_polygon.exterior.coords)
        constraints = []
        num_points = len(coords) - 1  # Last point is the same as the first point

        for i in range(num_points):
            p1 = coords[i]
            p2 = coords[i + 1]

            # Compute the line coefficients a*x + b*y = c
            a = p2[1] - p1[1]
            b = p1[0] - p2[0]
            c = a * p1[0] + b * p1[1]

            # Normalize coefficients
            norm = np.hypot(a, b)
            if norm == 0:
                rospy.logwarn(f"Degenerate edge detected between points {p1} and {p2}. Skipping.")
                continue  # Skip degenerate edges
            a /= norm
            b /= norm
            c /= norm

            # Determine the inequality direction
            # We'll ensure that the interior of the polygon satisfies a*x + b*y <= c
            midpoint = ((p1[0] + p2[0]) / 2.0, (p1[1] + p2[1]) / 2.0)
            normal_point = (midpoint[0] + a, midpoint[1] + b)
            point_inside = Point(normal_point).within(boundary_polygon)

            if point_inside:
                # Inequality is a*x + b*y <= c
                constraints.append((a, b, c))
            else:
                # Flip the inequality
                a *= -1
                b *= -1
                c *= -1
                constraints.append((a, b, c))

            # Log the constraint for debugging
            rospy.logdebug(f"Constraint {i}: a={a:.4f}, b={b:.4f}, c={c:.4f}, point_inside={point_inside}")

        return constraints

    def plot_track_and_position(self):
        # Plot the track boundaries
        fig, ax = plt.subplots(figsize=(self.fig_width, self.fig_height), dpi=self.dpi)
        # Plot outer boundary
        x_outer, y_outer = self.outer_boundary_polygon.exterior.xy
        ax.plot(x_outer, y_outer, 'b-', label='Outer Boundary (Original)')
        # Plot inner boundary
        x_inner, y_inner = self.inner_boundary_polygon.exterior.xy
        ax.plot(x_inner, y_inner, 'y-', label='Inner Boundary (Original)')

        # Plot shrunken outer boundary
        x_shrunk_outer, y_shrunk_outer = self.shrunken_outer_boundary.exterior.xy
        ax.plot(x_shrunk_outer, y_shrunk_outer, 'b--', label='Outer Boundary (Shrunken)')

        # Plot shrunken inner boundary
        x_shrunk_inner, y_shrunk_inner = self.shrunken_inner_boundary.exterior.xy
        ax.plot(x_shrunk_inner, y_shrunk_inner, 'y--', label='Inner Boundary (Shrunken)')

        # Plot trajectory if available
        if self.waypoints_received and len(self.waypoint_x) > 0:
            ax.plot(self.waypoint_x, self.waypoint_y, 'g.-', label='Received Trajectory')  # Updated label
            # Optionally, plot the historical trajectory
            if len(self.trajectory_history) > 1:
                traj_x, traj_y = zip(*self.trajectory_history)
                ax.plot(traj_x, traj_y, 'r-', label='Vehicle Trajectory')

        # Plot current position
        ax.plot(self.current_state[0], self.current_state[1], 'ro', label='Current Position')

        # Plot motor current as an annotation
        ax.annotate(f"Motor Current: {self.motor_current:.2f} A",
                    xy=(0.05, 0.95), xycoords='axes fraction',
                    fontsize=10, ha='left', va='top',
                    bbox=dict(boxstyle="round,pad=0.3", fc="yellow", alpha=0.5))

        # Highlight the current waypoint if available
        if self.current_waypoint is not None:
            ax.plot(self.current_waypoint[0], self.current_waypoint[1], 
                    marker='*', markersize=15, markeredgecolor='k', markerfacecolor='magenta', 
                    label='Current Waypoint')

        # Mark waypoints outside the shrunken track
        for idx, (x_wp, y_wp) in enumerate(zip(self.waypoint_x, self.waypoint_y)):
            wp_point = Point(x_wp, y_wp)
            if not self.track_polygon.contains(wp_point):
                ax.plot(x_wp, y_wp, 'rx')  # Mark as red x
                rospy.logwarn(f"Waypoint {idx} at ({x_wp:.2f}, {y_wp:.2f}) is outside the shrunken track boundaries.")

        ax.legend()
        ax.set_aspect('equal')
        plt.xlabel('X (m)')
        plt.ylabel('Y (m)')
        plt.title('Track Boundaries, Received Trajectory, Current Position, and Motor Current')

        # Draw the canvas and convert to image
        fig.canvas.draw()
        img = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
        img = img.reshape(fig.canvas.get_width_height()[::-1] + (3,))

        # Convert RGB to BGR for OpenCV
        img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        # Write the frame to the video
        self.video_writer.write(img_bgr)

        # Optionally, save individual frames as images
        # plt.savefig('./src/qcar_control/track_and_position.png')
        plt.close(fig)

        rospy.logdebug("Frame written to video.")

    def guid_callback(self, msg):
        if not self.waypoints_received:
            self.initial_waypoints_received_time = rospy.Time.now()
            self.waypoints_received = True
            rospy.loginfo("Initial waypoints received and time stored.")

        self.waypoint_times = msg.waypoint_times
        self.waypoint_x = msg.waypoint_x
        self.waypoint_y = msg.waypoint_y
        self.waypoint_velocity = msg.velocity
        rospy.loginfo(f"Updated waypoints: {len(self.waypoint_x)} points")

        # Plot the trajectory each time new waypoints are received
        self.plot_track_and_position()

    def velocity_callback(self, msg):
        self.current_state[3] = msg.vector.x  # Forward velocity in m/s
        rospy.logdebug(f"Received velocity: {self.current_state[3]:.2f} m/s")

    def vicon_callback(self, msg):
        self.current_state[0] = msg.transform.translation.x
        self.current_state[1] = msg.transform.translation.y
        self.current_state[2] = self.quat_to_yaw(msg.transform.rotation)
        self.trajectory_history.append((self.current_state[0], self.current_state[1]))
        rospy.logdebug(f"Updated position from Vicon: x={self.current_state[0]:.2f}, "
                       f"y={self.current_state[1]:.2f}, psi={self.current_state[2]:.2f}")

        # Check if current position is inside the shrunken track
        current_point = Point(self.current_state[0], self.current_state[1])
        if not self.track_polygon.contains(current_point):
            rospy.logwarn(f"Current position ({self.current_state[0]:.2f}, {self.current_state[1]:.2f}) is outside the shrunken track boundaries.")
            # Create and populate the command message
            command_msg = Vector3Stamped()
            command_msg.vector.x = 0  # PWM command (normalized)
            command_msg.vector.y = 0

            self.cmd_pub.publish(command_msg)
            self.pause = True
            input("Script paused. Press Enter to continue...")

            # Log the bounds of the track polygon for debugging
            minx, miny, maxx, maxy = self.track_polygon.bounds
            rospy.logdebug(f"Track polygon bounds: minx={minx:.2f}, miny={miny:.2f}, maxx={maxx:.2f}, maxy={maxy:.2f}")
        else:
            rospy.logdebug(f"Current position ({self.current_state[0]:.2f}, {self.current_state[1]:.2f}) is inside the shrunken track boundaries.")

        # Plot initial position after receiving first Vicon data
        if not self.initial_position_plotted:
            self.plot_track_and_position()
            self.initial_position_plotted = True

    def quat_to_yaw(self, q):
        """
        Convert quaternion to yaw angle (psi).
        """
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return np.arctan2(siny_cosp, cosy_cosp)

    def command(self, tau_cmd, steering_angle):
        # Map torque command to PWM command
        tau_motor = tau_cmd / self.gear_ratio

        # Compute applied voltage based on torque command and current velocity
        omega_wheel = self.current_state[3] / self.r_wheel  # Wheel angular speed (rad/s)
        omega_motor = omega_wheel * self.gear_ratio  # Motor angular speed (rad/s)
        V_back_emf = self.K_b * omega_motor  # Back-EMF voltage (V)
        I_motor = tau_motor / self.K_t  # Motor current (A)
        V_applied = self.R_a * I_motor + V_back_emf  # Applied voltage (V)
        PWM_cmd = (V_applied / self.V_max)  # Normalize PWM to 0-1 range

        # Clip PWM to [0, 1]
        PWM_cmd = np.clip(PWM_cmd, 0.0, 1.0)

        # Ensure PWM rate constraints are respected in command
        delta_PWM = PWM_cmd - self.PWM_cmd_prev
        if delta_PWM > self.delta_PWM_max_up:
            delta_PWM = self.delta_PWM_max_up
        elif delta_PWM < self.delta_PWM_max_down:
            delta_PWM = self.delta_PWM_max_down
        PWM_cmd = self.PWM_cmd_prev + delta_PWM

        # Clip again in case of numerical issues
        PWM_cmd = np.clip(PWM_cmd, 0.0, 1.0)

        # Create and populate the command message
        command_msg = Vector3Stamped()
        command_msg.vector.x = PWM_cmd  # PWM command (normalized)
        command_msg.vector.y = steering_angle

        self.cmd_pub.publish(command_msg)

        # Update previous PWM command
        self.PWM_cmd_prev = PWM_cmd

        # Log the commands for debugging
        rospy.loginfo(f"Commanding PWM: {PWM_cmd * 100.0:.2f}%, Steering Angle: "
                      f"{np.degrees(steering_angle):.2f} degrees")

    def get_waypoints_over_horizon(self):
        if not self.waypoints_received:
            rospy.logwarn("No waypoints received yet")
            return None, None

        current_time = rospy.Time.now()
        elapsed_time = (current_time - self.initial_waypoints_received_time).to_sec()

        if not self.waypoint_times:
            rospy.logwarn("Waypoint times list is empty")
            return None, None

        # Find the index of the first waypoint after the current time
        idx = np.searchsorted(self.waypoint_times, elapsed_time)

        # Remove the first index
        idx += 1

        # Prepare waypoints over the horizon
        waypoints_x = []
        waypoints_y = []
        v_refs = []

        for k in range(self.N):
            index = idx + k
            if index < len(self.waypoint_times):
                waypoints_x.append(self.waypoint_x[index])
                waypoints_y.append(self.waypoint_y[index])
                v_refs.append(self.waypoint_velocity[index])
            else:
                # Use the last waypoint if we run out
                waypoints_x.append(self.waypoint_x[-1])
                waypoints_y.append(self.waypoint_y[-1])
                v_refs.append(self.waypoint_velocity[-1])

        waypoints = np.vstack((waypoints_x, waypoints_y))
        v_refs = np.array([v_refs])

        return waypoints, v_refs

    def angle_difference(self, angle1, angle2):
        """
        Compute the smallest difference between two angles.
        """
        return np.arctan2(np.sin(angle2 - angle1), np.cos(angle2 - angle1))

    def setup_mpc(self):
        opti = ca.Opti()

        N = self.N  # Prediction horizon

        # State variables
        x = opti.variable(4, N+1)  # [x, y, psi, v]

        # Control variables
        u = opti.variable(2, N)  # [tau, delta]

        # Parameters for initial state and target
        x0 = opti.parameter(4)
        waypoints = opti.parameter(2, N)  # Waypoints over the horizon
        v_refs = opti.parameter(1, N)     # Reference velocities over the horizon
        u_prev = opti.parameter(1)        # Previous steering angle command
        PWM_prev = opti.parameter(1)      # Previous PWM command
        I_measured = opti.parameter(1)    # Measured motor current

        # Define dynamics
        def f(x, u):
            return ca.vertcat(
                x[3] * ca.cos(x[2]),  # dx/dt = v * cos(psi)
                x[3] * ca.sin(x[2]),  # dy/dt = v * sin(psi)
                x[3] / self.L * ca.tan(u[1]),  # dpsi/dt = v / L * tan(delta)
                (u[0] * self.gear_ratio / (self.mass * self.r_wheel)) - (self.c_d * x[3]) / self.mass  # dv/dt
            )

        # Objective function
        J = 0
        for k in range(N):
            # Position error
            J += self.w_pos * ca.sumsqr(x[:2, k] - waypoints[:, k])

            # Heading error
            desired_heading = ca.atan2(waypoints[1, k] - x[1, k],
                                       waypoints[0, k] - x[0, k])
            heading_error = ca.atan2(ca.sin(desired_heading - x[2, k]),
                                     ca.cos(desired_heading - x[2, k]))
            J += self.w_psi * heading_error**2

            # Velocity error
            J += self.w_v * (x[3, k] - v_refs[0, k])**2

            # Control effort
            J += self.w_u_p * (u[0, k])**2  # Torque effort
            J += self.w_u_d * (u[1, k])**2  # Steering effort

            # Torque-current alignment (only for the first control step)
            if k == 0:
                tau_actual = self.K_t * I_measured * self.gear_ratio  # Actual torque based on motor current
                J += self.w_tau_current * (u[0, k] - tau_actual)**2  # Penalize deviation

        opti.minimize(J)

        # Dynamics constraints
        for k in range(N):
            x_next = x[:, k] + self.dt * f(x[:, k], u[:, k])
            opti.subject_to(x[:, k+1] == x_next)

        # Input constraints
        opti.subject_to(opti.bounded(self.tau_min, u[0, :], self.tau_max))  # Torque limits
        opti.subject_to(opti.bounded(self.delta_min, u[1, :], self.delta_max))  # Steering limits

        # State constraints
        opti.subject_to(opti.bounded(0.0, x[3, :], 3.0))  # Velocity limits

        # Slew rate constraints for steering angle
        opti.subject_to(opti.bounded(-self.delta_delta_max,
                                     u[1, 0] - u_prev, self.delta_delta_max))
        for k in range(1, N):
            opti.subject_to(opti.bounded(-self.delta_delta_max,
                                         u[1, k] - u[1, k-1], self.delta_delta_max))

        # Proper Velocity Slew Rate Constraints
        for k in range(N):
            # Ensure that the change in velocity between consecutive steps
            # does not exceed the defined acceleration limits
            opti.subject_to(x[3, k+1] - x[3, k] <= self.delta_v_max)
            opti.subject_to(x[3, k+1] - x[3, k] >= self.delta_v_min)

        # PWM Constraints
        PWM_cmds = []
        for k in range(N):
            V_applied = self.R_a * (u[0, k] / self.gear_ratio / self.K_t) + \
                        self.K_b * (x[3, k] / self.r_wheel * self.gear_ratio)
            PWM_cmd = V_applied / self.V_max
            PWM_cmds.append(PWM_cmd)

            # Ensure PWM_cmd is between 0 and 1
            opti.subject_to(PWM_cmd >= 0.0)
            opti.subject_to(PWM_cmd <= 1.0)

        # PWM rate constraints with separate maximum increase and decrease
        for k in range(N):
            if k == 0:
                delta_PWM = PWM_cmds[0] - PWM_prev
            else:
                delta_PWM = PWM_cmds[k] - PWM_cmds[k-1]
            # Apply separate constraints for maximum increase and decrease
            opti.subject_to(delta_PWM <= self.delta_PWM_max_up)
            opti.subject_to(delta_PWM >= self.delta_PWM_max_down)

        # Initial condition
        opti.subject_to(x[:, 0] == x0)

        # Define parameters for motor current and previous PWM
        self.I_measured = I_measured
        self.PWM_prev = PWM_prev

        # Solver options
        opts = {'ipopt.print_level': 0, 'print_time': 0}
        opti.solver('ipopt', opts)

        self.opti = opti
        self.x = x
        self.u = u
        self.x0 = x0
        self.waypoints = waypoints
        self.v_refs = v_refs
        self.u_prev = u_prev

    def solve_mpc(self):
        try:
            waypoints, v_refs = self.get_waypoints_over_horizon()
            if waypoints is None or v_refs is None:
                rospy.logwarn("No valid waypoints or velocities available for MPC solve.")
                return

            self.opti.set_value(self.x0, self.current_state)
            self.opti.set_value(self.waypoints, waypoints)
            self.opti.set_value(self.v_refs, v_refs)
            self.opti.set_value(self.u_prev, self.steering_cmd_prev)
            self.opti.set_value(self.PWM_prev, self.PWM_cmd_prev)
            self.opti.set_value(self.I_measured, self.motor_current)  # Set the measured motor current

            # Initial guesses
            self.opti.set_initial(self.u, np.zeros((2, self.N)))
            self.opti.set_initial(self.x, np.tile(self.current_state.reshape(-1, 1),
                                                  (1, self.N+1)))

            sol = self.opti.solve()

            tau_cmd = sol.value(self.u[0, 0])
            steering_cmd = sol.value(self.u[1, 0])

            # Update the previous steering command
            self.steering_cmd_prev = steering_cmd

            # Command the vehicle
            self.command(tau_cmd, steering_cmd)

            # Identify and store the current waypoint (first in the horizon)
            self.current_waypoint = waypoints[:, 0]

            # Plot and write to video
            self.plot_track_and_position()

            # Logging
            self.log_debug(tau_cmd, steering_cmd, waypoints, v_refs)

        except Exception as e:
            rospy.logerr(f"MPC solver failed: {str(e)}")
            # Add more detailed exception information
            import traceback
            rospy.logerr("Exception traceback: " + traceback.format_exc())

    def command(self, tau_cmd, steering_angle):
        # Map torque command to PWM command
        tau_motor = tau_cmd / self.gear_ratio

        # Compute applied voltage based on torque command and current velocity
        omega_wheel = self.current_state[3] / self.r_wheel  # Wheel angular speed (rad/s)
        omega_motor = omega_wheel * self.gear_ratio  # Motor angular speed (rad/s)
        V_back_emf = self.K_b * omega_motor  # Back-EMF voltage (V)
        I_motor = tau_motor / self.K_t  # Motor current (A)
        V_applied = self.R_a * I_motor + V_back_emf  # Applied voltage (V)
        PWM_cmd = (V_applied / self.V_max)  # Normalize PWM to 0-1 range

        # Clip PWM to [0, 1]
        PWM_cmd = np.clip(PWM_cmd, 0.0, 1.0)

        # Ensure PWM rate constraints are respected in command
        delta_PWM = PWM_cmd - self.PWM_cmd_prev
        if delta_PWM > self.delta_PWM_max_up:
            delta_PWM = self.delta_PWM_max_up
        elif delta_PWM < self.delta_PWM_max_down:
            delta_PWM = self.delta_PWM_max_down
        PWM_cmd = self.PWM_cmd_prev + delta_PWM

        # Clip again in case of numerical issues
        PWM_cmd = np.clip(PWM_cmd, 0.0, 1.0)

        # Create and populate the command message
        command_msg = Vector3Stamped()
        command_msg.vector.x = PWM_cmd  # PWM command (normalized)
        command_msg.vector.y = steering_angle

        self.cmd_pub.publish(command_msg)

        # Update previous PWM command
        self.PWM_cmd_prev = PWM_cmd

        # Log the commands for debugging
        rospy.loginfo(f"Commanding PWM: {PWM_cmd * 100.0:.2f}%, Steering Angle: "
                      f"{np.degrees(steering_angle):.2f} degrees")

    def get_waypoints_over_horizon(self):
        if not self.waypoints_received:
            rospy.logwarn("No waypoints received yet")
            return None, None

        current_time = rospy.Time.now()
        elapsed_time = (current_time - self.initial_waypoints_received_time).to_sec()

        if not self.waypoint_times:
            rospy.logwarn("Waypoint times list is empty")
            return None, None

        # Find the index of the first waypoint after the current time
        idx = np.searchsorted(self.waypoint_times, elapsed_time)

        # Remove the first index
        idx += 10

        # Prepare waypoints over the horizon
        waypoints_x = []
        waypoints_y = []
        v_refs = []

        for k in range(self.N):
            index = idx + k
            if index < len(self.waypoint_times):
                waypoints_x.append(self.waypoint_x[index])
                waypoints_y.append(self.waypoint_y[index])
                v_refs.append(self.waypoint_velocity[index])
            else:
                # Use the last waypoint if we run out
                waypoints_x.append(self.waypoint_x[-1])
                waypoints_y.append(self.waypoint_y[-1])
                v_refs.append(self.waypoint_velocity[-1])

        waypoints = np.vstack((waypoints_x, waypoints_y))
        v_refs = np.array([v_refs])

        return waypoints, v_refs

    def angle_difference(self, angle1, angle2):
        """
        Compute the smallest difference between two angles.
        """
        return np.arctan2(np.sin(angle2 - angle1), np.cos(angle2 - angle1))

    def log_debug(self, tau_cmd, steering_cmd, waypoints, v_refs):
        current_waypoint_x = waypoints[0, 0]
        current_waypoint_y = waypoints[1, 0]
        current_velocity = v_refs[0, 0]
        desired_heading = np.arctan2(current_waypoint_y - self.current_state[1],
                                     current_waypoint_x - self.current_state[0])
        heading_error = self.angle_difference(self.current_state[2], desired_heading)

        # Calculate distance to waypoint
        distance_to_waypoint = np.sqrt(
            (self.current_state[0] - current_waypoint_x)**2 +
            (self.current_state[1] - current_waypoint_y)**2
        )

        # Calculate PWM command for logging
        omega_wheel = self.current_state[3] / self.r_wheel  # Wheel angular speed (rad/s)
        omega_motor = omega_wheel * self.gear_ratio  # Motor angular speed (rad/s)
        V_back_emf = self.K_b * omega_motor  # Back-EMF voltage (V)
        I_motor = (tau_cmd / self.gear_ratio) / self.K_t  # Motor current (A)
        V_applied = self.R_a * I_motor + V_back_emf  # Applied voltage (V)
        PWM_cmd = (V_applied / self.V_max)  # Normalize PWM to 0-1 range

        # Clip PWM to [0, 1]
        PWM_cmd = np.clip(PWM_cmd, 0.0, 1.0)

        debug_info = [
            ("Current Position (Vicon)", f"({self.current_state[0]:.2f}, {self.current_state[1]:.2f})"),
            ("Current Heading (Vicon)", f"{np.degrees(self.current_state[2]):.2f} degrees"),
            ("Current Velocity", f"{self.current_state[3]:.2f} m/s"),
            ("Motor Current", f"{self.motor_current:.4f} A"),  # Added motor current to debug info
            ("Wheel Torque Command", f"{tau_cmd:.6f} N·m"),
            ("Motor Torque Command", f"{tau_cmd / self.gear_ratio:.6f} N·m"),
            ("PWM Command", f"{PWM_cmd * 100.0:.2f}%"),
            ("Steering Angle Command", f"{np.degrees(steering_cmd):.2f} degrees"),
            ("Current Waypoint", f"({current_waypoint_x:.2f}, {current_waypoint_y:.2f})"),
            ("Target Velocity", f"{current_velocity:.2f} m/s"),
            ("Distance to Waypoint", f"{distance_to_waypoint:.4f} m"),
            ("Heading Error", f"{np.degrees(heading_error):.2f} degrees")
        ]

        rospy.loginfo("-------- MPC Debug Information --------")
        for key, value in debug_info:
            rospy.loginfo(f"{key}: {value}")
        rospy.loginfo("----------------------------------------")

    def run(self):
        rate = rospy.Rate(30)  # 20 Hz

        while not rospy.is_shutdown():
            if not self.pause:
                self.solve_mpc()
            rate.sleep()

        # Upon shutdown, send zero commands and release video writer
        self.command(0.0, 0.0)
        self.video_writer.release()
        rospy.loginfo("Video writer released and node shutdown.")

if __name__ == '__main__':
    try:
        controller = MPCControllerSimulation()
        controller.run()
    except rospy.ROSInterruptException:
        pass
